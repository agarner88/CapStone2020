public class ScientificCalcOperations {

	public double multiply(double a, double b) {
		return a * b;
		
	}
	
	public double squareRoot(double a) {
		return Math.sqrt(a);
	}

	public double divide(double g, double h) {
		return g/h;
	}

	public double divide1(double c, double f) {
		return c/f;
	}

	public double addition(double d, double e) {
		
		return d+e;
	}

	public double subtraction(double d, double e) {
	
		return d-e;
	}


	public double modulo(double d, double e) {
		
		return  (int)d%(int)e;

	}



	public double log10(double ops) {
		return Math.log10 (ops);
	}


	public double sin(double ops) {
		return Math.sin(ops);
	}


}